let gameState = "campo";
let truck;
let products = [];
let totalToCollect = 6;
let collected = 0;
let message = "";
let draggingItem = null;
let marketX;

let farmItems = ["🍎", "🥕", "🌽", "🍓", "🍉", "🥔"];
let nonFarmItems = ["📱", "💻", "📷", "👟", "🎧"];
let truckEmoji = "🚛";
let marketEmoji = "🏪";

function setup() {
  createCanvas(800, 400);
  textAlign(CENTER, CENTER);
  textSize(32);
  truck = new Truck();
  marketX = width - 60;

  // Cria 12 produtos (metade agrícolas, metade não)
  for (let i = 0; i < 12; i++) {
    let type = i % 2 === 0 ? "farm" : "nonfarm"; // Alterna entre tipos
    products.push(new ProductItem(type));
  }
}

function draw() {
  background(120, 200, 120);

  // Mercado
  textSize(40);
  text(marketEmoji, marketX, height - 50);
  
  // UI
  textSize(20);
  fill(0);
  text(`Coletados: ${collected} / ${totalToCollect}`, 120, 30);
  text(message, width / 2, 30);

  // Produtos
  for (let product of products) {
    product.show();
  }

  // Caminhão
  truck.update();
  truck.show();

  // Verifica se pode ir ao mercado
  if (collected >= totalToCollect) {
    fill(0);
    text("🚛 Caminhão carregado! Vá até o mercado 🏪 ➡️", width / 2, 60);
    if (truck.x > marketX - 30) {
      gameState = "cidade";
    }
  }

  // Fim do jogo
  if (gameState === "cidade") {
    background(180);
    textSize(28);
    text("Entrega realizada com sucesso! 🎉", width / 2, height / 2);
  }
}

// Interação com mouse
function mousePressed() {
  for (let product of products) {
    if (product.isMouseOver() && !product.collected) {
      draggingItem = product;
      break;
    }
  }
}

function mouseDragged() {
  if (draggingItem) {
    draggingItem.x = mouseX;
    draggingItem.y = mouseY;
  }
}

function mouseReleased() {
  if (draggingItem && gameState === "campo") {
    if (draggingItem.overlaps(truck)) {
      if (draggingItem.type === "farm" && !draggingItem.collected) {
        collected++;
        draggingItem.collected = true;
        message = "✔ Produto agrícola carregado!";
      } else if (draggingItem.type === "nonfarm") {
        message = "✘ Produto não agrícola!";
      }
    }
    draggingItem = null;
  }
}

// Classe do Caminhão
class Truck {
  constructor() {
    this.x = 100;
    this.y = height - 50;
    this.size = 32;
  }

  update() {
    if (collected >= totalToCollect && keyIsDown(RIGHT_ARROW)) {
      this.x += 4;
    }
  }

  show() {
    textSize(this.size);
    text(truckEmoji, this.x, this.y);
  }

  getBounds() {
    return { x: this.x - 16, y: this.y - 16, w: 32, h: 32 };
  }
}

// Classe dos Produtos
class ProductItem {
  constructor(type) {
    this.type = type;
    this.emoji = type === "farm" ? random(farmItems) : random(nonFarmItems);
    this.x = random(50, width - 150);
    this.y = random(100, height - 100);
    this.size = 28;
    this.collected = false;
  }

  show() {
    if (!this.collected) {
      textSize(this.size);
      text(this.emoji, this.x, this.y);
    }
  }

  isMouseOver() {
    return dist(mouseX, mouseY, this.x, this.y) < 20;
  }

  overlaps(truck) {
    let t = truck.getBounds();
    return (
      this.x > t.x &&
      this.x < t.x + t.w &&
      this.y > t.y &&
      this.y < t.y + t.h
    );
  }
}